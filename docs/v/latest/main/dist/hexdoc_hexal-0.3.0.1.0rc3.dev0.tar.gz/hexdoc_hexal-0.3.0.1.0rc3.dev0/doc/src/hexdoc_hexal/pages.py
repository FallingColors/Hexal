
from hexdoc.patchouli.page import EmptyPage


class EverbookEntryPage(EmptyPage, type="hexcasting:everbook_entry"):
    pass